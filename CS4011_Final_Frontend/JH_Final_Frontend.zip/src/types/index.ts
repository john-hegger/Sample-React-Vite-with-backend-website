export interface BlogPost {
    id: string;
    title: string;
    author: string;
    content: string;
    date: Date;
}
